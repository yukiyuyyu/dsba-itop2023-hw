#include "adddatawindow.h"

AddDataWindow::AddDataWindow()
{

}
