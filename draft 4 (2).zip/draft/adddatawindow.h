#ifndef ADDDATAWINDOW_H
#define ADDDATAWINDOW_H


class AddDataWindow
{
public:
    AddDataWindow();
};

#endif // ADDDATAWINDOW_H
